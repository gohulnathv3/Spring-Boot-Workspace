package io.spring.LearningSpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
