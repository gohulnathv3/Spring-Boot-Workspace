package io.spring.ObjectMapperSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObjectMapperSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObjectMapperSpringbootApplication.class, args);
	}

}
