package io.spring.ObjectMapperSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjectMapperSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
