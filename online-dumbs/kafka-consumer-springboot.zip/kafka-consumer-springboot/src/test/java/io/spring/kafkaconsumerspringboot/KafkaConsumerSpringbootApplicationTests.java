package io.spring.kafkaconsumerspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaConsumerSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
