package io.spring.mongodbgenerateSequence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbGenerateSequenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
