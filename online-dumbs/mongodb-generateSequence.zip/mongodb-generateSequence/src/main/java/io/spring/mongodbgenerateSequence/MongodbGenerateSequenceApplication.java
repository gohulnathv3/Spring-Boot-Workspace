package io.spring.mongodbgenerateSequence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodbGenerateSequenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodbGenerateSequenceApplication.class, args);
	}

}
