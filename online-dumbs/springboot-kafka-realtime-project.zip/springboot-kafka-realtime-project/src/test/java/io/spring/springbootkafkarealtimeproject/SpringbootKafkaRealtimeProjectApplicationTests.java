package io.spring.springbootkafkarealtimeproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKafkaRealtimeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
